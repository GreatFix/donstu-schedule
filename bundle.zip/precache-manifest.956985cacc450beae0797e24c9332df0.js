self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "219bf67bf0affd6afe5c9a4d454f3502",
    "url": "/index.html"
  },
  {
    "revision": "ab5d8bde5727b6608191",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "1588e6ebd03e99db5d2e",
    "url": "/static/css/main.35514d12.chunk.css"
  },
  {
    "revision": "ab5d8bde5727b6608191",
    "url": "/static/js/2.4c4e61bb.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4c4e61bb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1588e6ebd03e99db5d2e",
    "url": "/static/js/main.97948891.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);