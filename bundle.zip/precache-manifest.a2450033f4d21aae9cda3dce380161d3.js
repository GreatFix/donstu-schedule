self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5493bb5e5cd059ba97f5b1c959f56aae",
    "url": "/index.html"
  },
  {
    "revision": "ab8d076881c886f293c5",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "01cb07c49aa6159cc2af",
    "url": "/static/css/main.999df04b.chunk.css"
  },
  {
    "revision": "ab8d076881c886f293c5",
    "url": "/static/js/2.ccb2bb34.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.ccb2bb34.chunk.js.LICENSE.txt"
  },
  {
    "revision": "01cb07c49aa6159cc2af",
    "url": "/static/js/main.746cb02d.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);