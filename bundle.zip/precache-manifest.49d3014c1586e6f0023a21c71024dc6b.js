self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a093f0bc7ed6377de73897a9ac384904",
    "url": "/index.html"
  },
  {
    "revision": "0ca9143eac18d2903fe2",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "b3924fb6d44bede3c5c3",
    "url": "/static/css/main.ed855b1a.chunk.css"
  },
  {
    "revision": "0ca9143eac18d2903fe2",
    "url": "/static/js/2.3421c187.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.3421c187.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b3924fb6d44bede3c5c3",
    "url": "/static/js/main.522ac24e.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);