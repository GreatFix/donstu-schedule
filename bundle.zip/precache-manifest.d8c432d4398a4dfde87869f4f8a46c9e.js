self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b80ad33714a0e25c92c2534e1480865b",
    "url": "/index.html"
  },
  {
    "revision": "43535408f9c1e35fc90d",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "53c8ea878221e4b35654",
    "url": "/static/css/main.272dca9e.chunk.css"
  },
  {
    "revision": "43535408f9c1e35fc90d",
    "url": "/static/js/2.949ba7ba.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.949ba7ba.chunk.js.LICENSE.txt"
  },
  {
    "revision": "53c8ea878221e4b35654",
    "url": "/static/js/main.e6e550d9.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  }
]);