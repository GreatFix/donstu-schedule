self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f8232d59aa0f8953ea21e17fcb88937d",
    "url": "/index.html"
  },
  {
    "revision": "bd2f9b9e216ea09e2548",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "c7c92215ca628e4b0f0c",
    "url": "/static/css/main.35514d12.chunk.css"
  },
  {
    "revision": "bd2f9b9e216ea09e2548",
    "url": "/static/js/2.7ce05936.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.7ce05936.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c7c92215ca628e4b0f0c",
    "url": "/static/js/main.98c6a654.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);