self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0f5069f6728caa61d44d548948ce1478",
    "url": "/index.html"
  },
  {
    "revision": "c72a9bba7cf9b8060536",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "d1408150e0232f0a7536",
    "url": "/static/css/main.35514d12.chunk.css"
  },
  {
    "revision": "c72a9bba7cf9b8060536",
    "url": "/static/js/2.ea2a038d.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.ea2a038d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d1408150e0232f0a7536",
    "url": "/static/js/main.855772ac.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);