self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "50024ca2725209b593a4c428233edfcf",
    "url": "/index.html"
  },
  {
    "revision": "a1dcd1a5575aa7cdadf7",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "a1dcd1a5575aa7cdadf7",
    "url": "/static/js/2.808652e6.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.808652e6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d43bb8c0fdbd59b9bf94",
    "url": "/static/js/main.610b7b1c.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  }
]);