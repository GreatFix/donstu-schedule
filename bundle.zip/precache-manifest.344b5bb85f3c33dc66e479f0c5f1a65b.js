self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7193ab60e7368761b93864af07c90de5",
    "url": "/index.html"
  },
  {
    "revision": "b40169bfe9d48e04476d",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "afb91c27a815d315f4b8",
    "url": "/static/css/main.2af049f0.chunk.css"
  },
  {
    "revision": "b40169bfe9d48e04476d",
    "url": "/static/js/2.e45cd237.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.e45cd237.chunk.js.LICENSE.txt"
  },
  {
    "revision": "afb91c27a815d315f4b8",
    "url": "/static/js/main.6853bffb.chunk.js"
  },
  {
    "revision": "152999f2dabfe65e69bf",
    "url": "/static/js/runtime-main.4ba284d3.js"
  },
  {
    "revision": "05bcf8a77c774e76131912cb56772885",
    "url": "/static/media/logo.05bcf8a7.png"
  }
]);